package com.example.taylorhershberger.hershbergerfinal;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private ArrayAdapter<String> adapter;
    private ArrayList<String> workoutArray = new ArrayList<String>(){{
        add("Cardio");
        add("Strength");
        add("Flexibility");
    }};

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listWorkout = (ListView) this.findViewById(android.R.id.list);

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, workoutArray);
        listWorkout.setAdapter(adapter);

        //create listener
        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?>listView, View view, int position, long id){

                //create new intent
                Intent intent = new Intent(MainActivity.this, ActivityActivity.class);

                //start intent
                startActivity(intent);
            }
        };

        listWorkout.setOnItemClickListener(itemClickListener);

    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.create_order:
                Intent intent = new Intent(this, OrderActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
