package com.example.taylorhershberger.hershbergerfinal;

/**
 * Created by taylorhershberger on 5/6/18.
 */

public class Activity {
    private String name;
    private String url;

    public void getName(String activityname){
        name = activityname;
    }

    public String returnName(){
        return name;
    }

    public String returnURL(){
        return url;
    }

}
