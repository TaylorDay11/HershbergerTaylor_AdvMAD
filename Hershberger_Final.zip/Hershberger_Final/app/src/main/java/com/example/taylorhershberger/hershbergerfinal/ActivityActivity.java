package com.example.taylorhershberger.hershbergerfinal;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;

import java.util.ArrayList;

public class ActivityActivity extends Activity {

    private ArrayAdapter<String> adaptera;
    private ArrayList<String> urlArray = new ArrayList<String>();
    private ArrayList<String> activityArray = new ArrayList<String>(){{
        add("running");
        add("cycling");
    }};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity);

        ListView listActivities = (ListView) this.findViewById(android.R.id.list);


        adaptera = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, activityArray);

        listActivities.setAdapter(adaptera);


        final Button addButton=(Button)findViewById(R.id.add_button);

        addButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                addactivity();
            }
        });

        registerForContextMenu(listActivities);

    }

    public void addactivity(){
        //create alert dialog
        AlertDialog.Builder dialog = new AlertDialog.Builder(ActivityActivity.this);
//        View view = getLayoutInflater().inflate(R.layout.dialog_add, null);
        //create edit text
        final EditText editactivity = new EditText(ActivityActivity.this);
        final EditText editurl = new EditText(ActivityActivity.this);

        editactivity.setHint("Activity Name");
        editurl.setHint("URL");

        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.addView(editactivity);
        ll.addView(editurl);
        //add edit text to dialog
        dialog.setView(ll);
        //set dialog text
        dialog.setTitle("Add Activity");
        dialog.setPositiveButton("Save",new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int whichbutton){
                //get animal name
                String activityName = editactivity.getText().toString();
                String urlName = editurl.getText().toString();
                if(!activityName.isEmpty()){
                    Activity newActivity = new Activity();
                    activityArray.add(activityName);
                    //refresh the list view
                    ActivityActivity.this.adaptera.notifyDataSetChanged();
                }
            }
        });
        //sets cancel action button
        dialog.setNegativeButton("Cancel",new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int whichButton){
                //cancel;
            }
        });
        //present alert dialog
        dialog.show();
    }


    @Override public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu, view, menuInfo);
        AdapterView.AdapterContextMenuInfo adapterContextMenuInfo = (AdapterView.AdapterContextMenuInfo) menuInfo;
        //get animal name that was pressed
        String activityname = adaptera.getItem(adapterContextMenuInfo.position);
        //set menu title
        menu.setHeaderTitle("Delete " + activityname);
        //add the choices to the menu
        menu.add(1,1,1,"Yes");
        menu.add(2,2,2,"No");
    }

    @Override public boolean onContextItemSelected(MenuItem item){
        //get the id of the item
        int itemId = item.getItemId();
        if(itemId == 1){
            //if yes menu item was pressed
            //get the position of the menu item
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
            //remove the animal
            activityArray.remove(info.position);
            //refresh the list view
            ActivityActivity.this.adaptera.notifyDataSetChanged();
        }
        return true;
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.create_order:
                Intent intent = new Intent(this, OrderActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
